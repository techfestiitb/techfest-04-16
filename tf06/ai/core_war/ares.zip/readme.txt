 ==============================================================================
                                      A.R.E.S.
 ------------------------------------------------------------------------------
                         Active Redcode Elaboration System

            (c) 2004-2005 by Harald Markus Wirth, http://harald.ist.org
 ==============================================================================

 Version 2.27b (May 27th, 2005)

 Alltough ARES is not perfect, I would say, its now a gamma version. Because
 the assembler is still beta, I still define ARES v2.27 as a beta, too.

 I plan to rewrite the assembler next, but I am not sure, when I will find time
 and energy for this piece of work (The assembler is the most ugly part of
 code, lots of ifs). Use the "check for updates" function now and then.

 You will find the version history and my concept for the manual in this readme
 file. There is a copy of the ICWS-94 standard  definition included in the sub
 directory "more_stuff", and there are lots of tutorials for Redcode in the
 web, so you shouldn't have problems with using ARES. Feel free to contact me,
 if you have questions or suggestions.

 Download the latest version of ARES at  http://harald.ist.org/ares


 Files delivered in ares2.27b.zip
 --------------------------------

	ares.exe
	readme.txt

	ares_system <DIR>
		redcode.ico
		greencode.ico
		bluecode.ico
		lucon.ttf

	manual <DIR>
		index.html
		firstgame.html
		firstgame2.html
		firstgame3.html
		firstgame4.html
		firstgame5.html
		firstgame6.html
		firstgame7.html
		firstgame8.html
		firstgame9.html
		firstgame10.html
		firstgame11.html
		tutorial.html
		tutorial2.html
		tutorial3.html
		tutorial4.html
		tutorial5.html
		tutorial5b.html
		tutorial5c.html
		tutorial5d.html
		tutorial5e.html
		tutorial5f.html
		tutorial6.html
		tutorial6b.html
		tutorial7.html
		tutorial8.html
		tutorial9.html
		endtutorial.html
		_close.html
		default.css
		aresbg_red.gif
		aresbig.gif

	more_stuff <DIR>
		ICWS 94.htm

	warriors <DIR>
		WELCOME.red

		bluecode <DIR>
			dont_use_rom.blu
			use_with_rom.blu
		both <DIR>
			dwarfscout.red

		limit <DIR>
			littleseed2.red
			terrorseed2.red
			twins3.red

		nolimit <DIR>
			dwarf.red
			imp.red
			little.red
			very little.red


 Changes in version 2.27b
 ------------------------
 bugfixes
	ZEUS:	Core View: The yellow inspect label shows absoulute adresses ("&") no longer as underline of the first number. (Interpreted as shortcut)
	ARES:	Editor: Quick Help for adress modes and opcode modifiers reactivated
	ARES:	Options: Bug with RadioButtons removed (when pressed ESC or closed window by the X-button, the change was not taken back)

 changes
	ZEUS:	Debugger: Changed the trace behaviour, when a task is selected in a queue, to old version: It stops, when an IP-to-trace is on top
	ARES:	Tutorial: Remote controlled by the html file. (You can expand it by yourself)
	ARES:	You can now switch to FullScreen mode
	ARES:	Changed layout, registers (queues & p-space) are at the right side of the main window (useful, when debugging with open source file)
	ARES:	Editor: Can switch between 4 sizes now, if resolution high enough
	ARES:	You can automatically check for newer versions by using the menu entry
	
 known bugs
	ARES:	Tutorial/FullScreen: strange bug with the WebBrowser component: gets white on resize, hiding the panel causes errors
		as reloading the page or reassigning a page. But pressing F1 after resize works... !?


 Changes in version 2.26b
 ------------------------
 buxfixes:
	MARS:	Removed a bug in the R/W-Limit-Fold function

 changes
	ARES:   Editor: Compile & Trace: activates run mode RUN
        ARES:   readme.txt can be opened from help menu
	ARES:	It is now an "Inter-active Redcode Elaboration System": The tutorial has been implemented,
		but I am not sure, how good the Explorer Object, I used, really is. Testing will follow.
	ARES:	The shareware information is shown in the browser window, when feedback.html gets older than 30 days.
	ARES:	When feedback.html is missing, a popup window asks, if ARES should install the font "Lucida Console".


 Changes in version 2.25b
 ------------------------
 bugfixes
	MARS:	In-Register-Evaluation work with Read/Write Limits now
	MARS:	MOD.F no longer refuses to work
	ZEUS:	Core: Different colors are used now for differentiating Read/Write access
	ZEUS:	Core: Click to core view switches trace off only when in RUNNING mode
	ZEUS:	Monitor: Redraw (when moving between cells using cursor keys) in the middle of core memory (CORESIZE/2)
	ZEUS:	Monitor: Full output mode: .b-Value now also shows a "+", when immediate value
	ZEUS:	Monitor: Reset Simulator also clears EntryPoints
	ZEUS:	Tournament: Tournament halted on ASM error
	ARES:	Explorer windows placed behind ARES should no longer come into focus, when Asm-Message-Window closes
	ARES:	Filetypes: Links for .blu files work now

 changes
	MARS:	Core optimized, marginally faster now
	MARS:	Core size up to 1,000,000.
	HERMES:	VRAM a and b field swapped: a stores now the color and b the ascii code for the character
	HERMES:	Activating Bluecode automatically enables experimental mode
	HERMES:	Experimental Mode: Program B loaded to &1000
	HERMES:	Experimental Mode: Program B doesn't get started as second player, it will be called by ROM as Player A
	HERMES: Mini-ROM rewritten, two bluecode demo user programs added, that use HERMES-OS
	ASM:	did not change at all (still version ICWS94-1.32b)
	ZEUS:	Doubleclick to "A" and "B" in the top left corner of the main window clear Warrior A/B entries
	ZEUS:	Debugger: STEP runs until the next task marked as "to trace" comes up to execution
	ZEUS:	Debugger: "Flashed" cells stay visible until next STEP (Cycle)
	ZEUS:	Monitor: Visualisation of Read/Write accesses for better debugging
	ZEUS:	Monitor: Font optional
	ZEUS:	Monitor: Breakpoint visualisation changed (red: Breakpoint, yellow: "Tracepoint")
	ZEUS:	Monitor: Experimental mode indicated by drawing the box around the centered cell blue
	ZEUS:	Monitor: Non-Full-Output: Modifiers hidden, if default
	ZEUS:	Monitor: Experimental Mode: END-Key moves to VRAM_TOP, Pos1 to &000000
	ZEUS:	Tournament: Window sizeable
	ZEUS:	Animate Access got a shortcut
	ZEUS:	Core: Rightclick-->fast-mode: restores "upd"-states when returning to normal display mode
	ARES:	Menu shortcuts changed, some button shortcuts (ALT-Letter), too
	ARES:	Window fully sizeable, Editor can switch between 3 size steps (only at 1280x1024 or higher)
	ARES:	Compiler messages can now be hidden (verbouse assembly mode)
	ARES:	Tweaked some UI behavior
	ARES:	feedback.html is atomatically generated and a popup is shown one month later
	ARES:	Options: Shortcuts can be user defined
	ARES:	Options: When setting core size to a certain size, zoom is changed (bitmaps size ares limited)
	ARES:	Editor: Buttons got shortcuts
	ARES:	Editor: Status messages also shown in QuickHelp-label
	ARES:	Editor: QuickHelp extended: Modifiers, Adress Modes and Operators
	ARES:	3D-font: More characters
	ARES:	About: Constant frame rate in info box animation (at last, i can now read out the system clock in 1/200")
	ARES:	Shareware: Reminder pops up, when feedback.html gets older than 30 days
	ARES:	Main Window Maximized & Save Window Positions on Close: Coords not saved, but "Maximized-Flag" set in INI

 known bugs
	MARS:	Evaluation of registers: different Read/Write limits: only write pointers postincremented
	ASM:	FOR..ROF, multiple line EQU, Boolean Operators, ;assert and Load File Format still missing
	ASM:	EQU statements placed in the code are counted as instructions when calculating label offsets
	ASM:	A definition like "label EQU operation" can't be used to insert the operation into the program
	ASM:	labels must not be defined with a succeeding colon (":")
	ZEUS:	Monitor: DblClick another, while editing a cell: you need to click once, wait and the do the double click
	ZEUS:	Debugger: When redraw forced (eg. overlapping windows), read/write access animation disappears
	ZEUS:	Debugger: Watches disabled when speed up by right-clicking to core: Break Conditions switched off!
	ZEUS:	Debugger: Clicking on STEP when tracing some selected tasks works bad, but better than nothing
	ARES:	3D-Font: some special characters are missing
	ARES:	Dual Screens: Core View doesn't show the "+" cursor on the primary screen (Matrox G-400, Win98SE) 
	ARES:	Options: Shortcuts shown in options dialog, page ZEUS, not updated when customized
	ARES:	Options: Font set to eg. Fixedsys with 8pt (9pt only possible!) --> graphics error in Monitor


 Planned Future Extensions
 -------------------------
 ARES v2.2
	MARS:	external assembler option, fast/extern runs (Tournament)
	ASM:	boolean expressions
	ASM:	;assert directive
	ZEUS:	Watches no longer ListBox, but self made object (faster)
	ZEUS:	Tournament: Challenge (one warrior against a list of others)
	ZEUS:	Monitor: Flexible cursor (selected cell not only centered)
	ZEUS:	Tournament interruptible (and able to continue after reload)
	ZEUS:	P-Space editierbar
	ARES:	Editor: Auto indent
	ARES:	3D-font complete	

 ARES v2.3
	ASM:	compatible with pMARS, at least: multi line EQU, FOR, LoadFile
	ARES:	Automatic Hill Upload
	ARES:	Extended tutorials to different topics

 possible future extensions:
	ARES:	Online Help (F1-Key)
	ARES:	Editor: self made object instead of Memo. Syntax hilight (labels/opc/comments)
		Multiple FIFO (more than two players compete at the same time)
		ARES as Server (http interface with warrior upload)
		automatical download/inform about new ARES updates



Manual (Concept)
================

Main Window
-----------
Warrior Section
	Warrior A/B:
		Doubleclick to "A"/"B": Delete Selected
		Doubleclick to EditBox: Select File
		New (EditBox empty), Edit (if has entry) --> Editor
			Label Program A/B: which warrior is displayed?
			buttons: save&close, saveAs, Discard, Save&Compile, Save&Trace, Save&Run
			filename, column/row
			Quick Help (relates to text under cursor)
	Tournament
		3 Points/Win, 1 Point/Tie
	Compile + Run: start the fight
	Battle #, Fights Won: Statistics while tournament
Queues
	upd: disable queues (speedup)
	tasks: number of processes per Warrior
	Instruction Pointers of Warriors
		Click: Switch on/off trace this task
		DblClick: only trace this task
		RightClick: trace all tasks
P-Space
	upd: speedup
	A, B: PSpace f�r welchen Warrior anzeigen
	PSpace: Nr, Wert
		000000: Tournament
Core View
	upd: speedup
	Core memory: 
		linear from left to right / top to bottom, 
		100 cells per row (4x zoom)
		200 cpr (2x), 400 cpr (1x)
	MouseMove: Inspect cell
	Click: Center Monitor
	DblClick: Ed cell in Monitor
	RightClick: Speedup (Watches/Break Conditions don't work, when they're disabled!)
Status line
	(Error) messages
	M.A.R.S. Status (RunMode)
		RM_RUN: status displays: Cycles A:tasks(kills/suicides) B:tasks(kills/suicides)
Debugger
	Control Block
		Run: start simulator, entrypoints copied to queues initially
		Break: stop simulation, abort tournament
		continue: start sim without resetting queues (if possible)
		step: exec one CYCLE
	Trace Block
		RadioButtons: write selected entry point to A/B?
		entry point: set first command for selected player (RBtns)
		<empty space between entry point and trace program>: center cursor to next instruction
		Trace program: follow exec in monitor (scroll, if necessary)
			Want to trace all spawned tasks? --> Rightclick to Queue
		SetEntryPoint: copy adress of selected cell in monitor --> entry point for A/B
		Clear Queues: empty fifos, center to start adress
	Monitor
		upd: speedup
		Breakpoints - halt MARS before execution
		Tracepoints - halt MARS only, if a traced process is going to execute it
		Context Menu
	Watches
		enable: if enabled (visible) check for break conditions every step
		add watch: mon-selected to watches
		ed watch: set conditions			
		remove watch
MENU
----
	File
		Select A/B
		Edit A/B
		Compile to Core: compile only
		Compile & Run: like button in main window
		Tournament: everybody against everybody
		Dump Core: write core or part of core to .red file
	Simulator
		Debugger commands
		Watches
		Reset Sim
		Clear Mem
		Clear PSpace
		Options
	Window
		Asm-Msg
		Cpu
		Console
		Tournament Stats
		Legende
	Help
		fehltnoch
		About