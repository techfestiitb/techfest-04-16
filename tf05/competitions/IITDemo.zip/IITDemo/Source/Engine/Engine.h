#pragma once

#include "ctimemanagement.h"
#include "camera.h"
#include "../content/world.h"

class CMainFrame;

class Engine : public CTimeManagement
{
public:
	Engine(void);
	void				FinalCleanup(void);
	BOOL				Init(CMainFrame *mainFrame, PWT wt);

	void				OnRender(IWTEvent *eve);
	void				OnMouse(IWTEvent *eve);
	void				OnKeyboard(IWTEvent *eve);
	void				OnException(IWTEvent *eve);
	void				OutDebugString(const TCHAR *t);
	
	PWTKeyboardPollInfo&	GetKBPoll(void) { return m_wt_kbPoll; }

#ifdef	SID_DEBUG
	void				ShowLog(const BOOL show);
	void				PrintOnScreen(const int x, const int y, const TCHAR *str);
#endif	SID_DEBUG

private:
	CMainFrame			*m_mainFrame;
	RECT				m_rect;

	PWT					m_wt;
	PWTKeyboardPollInfo	m_wt_kbPoll;
	PWTMousePollInfo	m_wt_msPoll;

	PWTStage			m_wt_stage;
	PWTGroup			m_wt_stage_grp;

	Camera				m_camera;
	World				m_world;

#ifdef	SID_DEBUG
	PWTBitmap			m_wt_log_bmp;
	PWTDrop				m_wt_log_drp;
#endif	SID_DEBUG
};