#include "stdafx.h"
#include "../resource.h"
#include <time.h>
#include "../mainfrm.h"
#include "engine.h"

#define	SHOW_WORLD_CAM_ROTATION_DELTA		0.2f

Engine::Engine(void) : m_mainFrame(NULL)
{
	SetRectEmpty(&m_rect);
}
void Engine::FinalCleanup(void)
{
	m_world.FinalCleanup();
	m_wt_stage_grp.Release();
	m_camera.FinalCleanup();
	m_wt_stage.Release();
	m_wt.Release();
}
BOOL Engine::Init(CMainFrame *mainFrame, PWT wt)
{
	BOOL		res = TRUE;
	PWTCamera	wt_camera;

	if (NULL == mainFrame)
	{
		ERXIT;
	}
	m_mainFrame = mainFrame;
	m_mainFrame->GetClientRect(&m_rect);

	if(!Calibrate())
	{
		MessageBox(NULL, "Failed to calibrate timer", "ERROR", MB_OK|MB_ICONERROR) ;
		ERXIT;
	}

	m_wt = wt;
	if (m_wt == NULL)
	{
		ERXIT;
	}

	// set the version
	m_wt->debugWindow(TRUE);
	m_wt->designedForVersion("3.0", "", NULL);
	// set files path
	wt->setFilesPath("resources/");

	// create a stage
	m_wt_stage = m_wt->createStage();
	if (m_wt_stage == NULL)
	{
		ERXIT;
	}
	m_wt_stage->setBGColor(0, 0, 0);

	// create the camera
	wt_camera = m_wt_stage->createCamera();
	if (wt_camera == NULL)
	{
		ERXIT;
	}
	if (!m_camera.Init(wt_camera))
	{
		ERXIT;
	}

	m_wt_stage_grp = m_wt->createGroup();
	if (m_wt_stage_grp == NULL)
	{
		ERXIT;
	}
	m_wt_stage_grp->setName(_T("Stage_grp"));

	if (FAILED(m_wt_stage->addObject((PWTContainer)m_wt_stage_grp)))
	{
		ERXIT;
	}

#ifdef	SID_DEBUG
	const int width = m_rect.right - m_rect.left, height = m_rect.bottom - m_rect.top;
	m_wt_log_bmp = m_wt->createBlankBitmap(width, height);
	m_wt_log_bmp->setColor(0, 0, 0);
	m_wt_log_bmp->drawFillRect(0, 0, width, height);
	m_wt_log_bmp->setColorKey(0, 0, 0);
	m_wt_log_bmp->setTextHeight(10);
	m_wt_log_bmp->setTextBkColor(0, 0, 0);
	m_wt_log_bmp->setTextColor(255, 0, 0);
	m_wt_log_bmp->setTextFace("Courier, system");
	m_wt_log_bmp->setTextProperties(400, 0, 0, 0, 0, 0);
	m_wt_log_drp = m_camera.AddDrop(m_wt_log_bmp, TRUE);
	ShowLog(TRUE);
#endif	SID_DEBUG

	if (!m_world.Init(m_wt, m_wt_stage_grp))
	{
		ERXIT;
	}

	// start the scene rendering
	m_wt->start();
	// Tell the webdriver to notify us of events
	m_wt->setNotifyRenderEvent(true);
	m_wt->setNotifyKeyboardEvent(true);

	TimerRefresh();
xit:
	return res;
}

void Engine::OnRender(IWTEvent *eve)
{
	//Grap the input state
	m_wt_kbPoll = m_wt->pollKeyboard();
	m_wt_msPoll = m_wt->pollMouse();

	m_camera.RotateBy(0.0f, SHOW_WORLD_CAM_ROTATION_DELTA);

#ifdef	SID_DEBUG
	m_wt_log_bmp->setColor(0, 0, 0);
	TCHAR buffer[64];
	sprintf(buffer, _T("FPS: %f"), GetFPS());
	PrintOnScreen(m_rect.right - 150, 10, buffer);
#endif	SID_DEBUG

	//Update the camera
	m_camera.Update(this);

	//Refresh engine timer
	TimerRefresh();
}
void Engine::OnMouse(IWTEvent *eve)
{
}
void Engine::OnKeyboard(IWTEvent *eve)
{
	const int key = eve->getKey();

	if (0 == eve->getKeyState())
	{
		switch(key)
		{
			case 'F':
				m_camera.SetFreeCamMode();
			break;
		}
	}
}
void Engine::OnException(IWTEvent *eve)
{
}
void Engine::OutDebugString(const TCHAR *t)
{
	m_wt->outDebugString(t);
}

#ifdef	SID_DEBUG
void Engine::ShowLog(const BOOL show)
{
	m_wt_log_drp->setVisible(show);
}
void Engine::PrintOnScreen(const int x, const int y, const TCHAR *str)
{
	m_wt_log_bmp->drawText(x, y, str);
}
#endif	SID_DEBUG