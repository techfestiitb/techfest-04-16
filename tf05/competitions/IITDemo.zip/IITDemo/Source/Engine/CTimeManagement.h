#pragma once

#include <Windows.h>

#define TIME_COUNT_DATA_TYPE	__int64

#define TimerStop TimerStart

class CTimeManagement
{
private :
	union
	{
		struct
		{
			float			fFps,
							fLastLoopDuration,
							fFpsFactor ;
			DWORD			dwLastLoopDuration,
							dwTickCount ;
			int				nLastLoopDuration ;

			float			fFrequencyToCounterRatio ;

			TIME_COUNT_DATA_TYPE	LastTimeCount ;
			int				nElapsedTicks ;
		} ;
	} ;

protected :
	bool Calibrate() ;
	void TimerRefresh() ;

public :
	inline float GetFPSFactor()
	{
		return fFpsFactor;
	}

	inline float GetFPS()
	{
		return fFps;
	}

	inline float GetLastLoopDurationFloat()
	{
		return fLastLoopDuration ;
	}

	inline int GetLastLoopDuration()
	{
		return nLastLoopDuration ;
	}

	inline int GetElapsedTicks()
	{
		return nElapsedTicks ;
	}
	inline void TimerStart(TIME_COUNT_DATA_TYPE *count)
	{
		QueryPerformanceCounter((LARGE_INTEGER*)count) ;
	}

	inline int GetElapsed(const TIME_COUNT_DATA_TYPE &countStart, const TIME_COUNT_DATA_TYPE &countEnd)
	{
		TIME_COUNT_DATA_TYPE	diff = countEnd - countStart ;
		int						_nElapsedTicks ;
		_nElapsedTicks = (int)diff ;
		_nElapsedTicks = max(1,_nElapsedTicks) ;
		_nElapsedTicks = min(0x8ffffff0,_nElapsedTicks) ;

		float f = ((float)_nElapsedTicks) * fFrequencyToCounterRatio ;
		_nElapsedTicks = (int)((int)f) ;

		return _nElapsedTicks ;
	}
	
	inline int TimerCovert(DWORD &type, const TIME_COUNT_DATA_TYPE &countStart, const TIME_COUNT_DATA_TYPE &countEnd)
	{
		TIME_COUNT_DATA_TYPE	diff = countEnd - countStart ;
		int						_nElapsedTicks ;
		_nElapsedTicks = (int)diff ;
		_nElapsedTicks = max(1,_nElapsedTicks) ;
		_nElapsedTicks = min(0x8ffffff0,_nElapsedTicks) ;

		float f = ((float)_nElapsedTicks) * fFrequencyToCounterRatio ;
		type = (DWORD)((int)f) ;
		return _nElapsedTicks ;
	}

	void TimerReset() ;
} ;