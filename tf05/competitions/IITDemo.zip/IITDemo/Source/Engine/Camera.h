#pragma once

#include "../util/orientation.h"

enum CamState
{
	CAM_FREECAM
};

class Engine;

class Camera
{
public:
	void				FinalCleanup(void);
	BOOL				Init(PWTCamera wt_camera);

	void				Update(Engine *engine);

	//Freecam navigation///////////////////////////////////////////////////////
	void				SetFreeCamMode(void);
	void				NavigateCam(Engine &engine);
	///////////////////////////////////////////////////////////////////////////

	//Position stuff///////////////////////////////////////////////////////////
	void				SetPosition(const D3DXVECTOR3 &v);
	void				SetPosition(const float x, const float y, const float z);
	void				MoveForward(const float trans);
	void				MoveUp(const float trans);
	///////////////////////////////////////////////////////////////////////////

	//Rotation stuff///////////////////////////////////////////////////////////
	void				Rotate(const float xAngle, const float yAngle);
	void				RotateBy(const float xAngle, const float yAngle);
	///////////////////////////////////////////////////////////////////////////

	//WTDrop stuff/////////////////////////////////////////////////////////////
	PWTDrop				AddDrop(PWTBitmap &wt_bmp, const BOOL front);
	void				RemoveDrop(PWTDrop &wt_drp);
	///////////////////////////////////////////////////////////////////////////

private:
	PWTCamera			m_wt_camera;
	CamState			m_cam_state;
	UTIL::Orientation	m_orientation;
};