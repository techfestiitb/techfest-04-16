#include "stdafx.h"
#include "CTimeManagement.h"

bool CTimeManagement::Calibrate()
{
	LARGE_INTEGER			li, pc ;

	if(!QueryPerformanceFrequency((LARGE_INTEGER*)&li))
	{
		return false ;
	}
	else
	{
		if(!QueryPerformanceCounter(&pc))
		{
			return false ;
		}
		fFrequencyToCounterRatio = 1000.0f / ((float)((DWORD)(int)li.QuadPart)) ;
	}

	return true ;
}

void CTimeManagement::TimerReset()
{
	TimerStop(&LastTimeCount) ;
}

void CTimeManagement::TimerRefresh()
{
	TIME_COUNT_DATA_TYPE		CurrTick ;
	TIME_COUNT_DATA_TYPE		diff ;

	TimerStop(&CurrTick) ;
	diff = CurrTick - LastTimeCount ;
	
	nElapsedTicks = (int)diff ;
	nElapsedTicks = max(1,nElapsedTicks) ;
	nElapsedTicks = min(0x8ffffff0,nElapsedTicks) ;

	const float f = min(150.0f, (((float)nElapsedTicks) * fFrequencyToCounterRatio)) ;
	fLastLoopDuration = f ;
	nLastLoopDuration = (int)f ;
	dwLastLoopDuration = (DWORD)(nLastLoopDuration) ;

	fFpsFactor	= f * 0.0303030303f ;
	fFps		= 1000.0f / f ;

	LastTimeCount = CurrTick ;
}