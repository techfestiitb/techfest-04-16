#include "stdafx.h"
#include "camera.h"
#include "engine.h"

#define	CAM_FOV						45.0f

//Freecam
#define	FREECAM_TRANS_SPEED			10.0f
#define	FREECAM_ROTATION_DELTA		5.0f

void Camera::FinalCleanup(void)
{
	m_wt_camera.Release();
}
BOOL Camera::Init(PWTCamera wt_camera)
{
	BOOL res = TRUE;

	if (wt_camera == NULL)
	{
		ERXIT;
	}

	m_cam_state = CAM_FREECAM;
	m_orientation.Init();

	m_wt_camera = wt_camera;
	m_wt_camera->setFieldOfView(CAM_FOV);

	SetPosition(0.0f, 20.0f, 0.0f);

xit:
	return res;
}

void Camera::Update(Engine *engine)
{
	switch(m_cam_state)
	{
		case CAM_FREECAM:
			NavigateCam(*engine);
		break;
	}
}

//Position stuff///////////////////////////////////////////////////////////////
void Camera::SetPosition(const D3DXVECTOR3 &v)
{
	m_orientation.SetPosition(v);
	m_wt_camera->setAbsolutePosition(v.x, v.y, v.z);
}
void Camera::SetPosition(const float x, const float y, const float z)
{
	D3DXVECTOR3 pos(x, y, z);
	m_orientation.SetPosition(pos);
	m_wt_camera->setAbsolutePosition(x, y, z);
}
void Camera::MoveForward(const float trans)
{
	m_orientation.MoveForward(trans);
	D3DXVECTOR3 pos;
	m_orientation.GetPosition(pos);
	m_wt_camera->setAbsolutePosition(pos.x, pos.y, pos.z);
}
void Camera::MoveUp(const float trans)
{
	m_orientation.MoveUp(trans);
	D3DXVECTOR3 pos;
	m_orientation.GetPosition(pos);
	m_wt_camera->setAbsolutePosition(pos.x, pos.y, pos.z);
}
///////////////////////////////////////////////////////////////////////////////

//Rotation stuff///////////////////////////////////////////////////////////////
void Camera::Rotate(const float xAngle, const float yAngle)
{
	m_orientation.SetRotation(xAngle, yAngle);
	m_orientation.SetOrientation((PWTContainer)m_wt_camera);
}
void Camera::RotateBy(float xAngle, float yAngle)
{
	m_orientation.RotateBy(xAngle, yAngle);
	m_orientation.SetOrientation((PWTContainer)m_wt_camera);
}
///////////////////////////////////////////////////////////////////////////////

//Freecam//////////////////////////////////////////////////////////////////////
void Camera::SetFreeCamMode(void)
{
	m_cam_state = CAM_FREECAM;
}
void Camera::NavigateCam(Engine &engine)
{
	float xRot = 0.0f, yRot = 0.0f, trans = 0.0f;

	PWTKeyboardPollInfo kbPoll = engine.GetKBPoll();
	const float fps_fac = engine.GetFPSFactor();

	if (kbPoll->isKeyDown(VK_LEFT) == 1)
		yRot += (FREECAM_ROTATION_DELTA * fps_fac);
	if (kbPoll->isKeyDown(VK_RIGHT) == 1)
		yRot -= (FREECAM_ROTATION_DELTA * fps_fac);
	if (kbPoll->isKeyDown(VK_UP) == 1)
		xRot -= (FREECAM_ROTATION_DELTA * fps_fac);	
	if (kbPoll->isKeyDown(VK_DOWN) == 1)
		xRot += (FREECAM_ROTATION_DELTA * fps_fac);
	if (kbPoll->isKeyDown('A') == 1)
		trans += (FREECAM_TRANS_SPEED * fps_fac);
	if (kbPoll->isKeyDown('Z') == 1)
		trans -= (FREECAM_TRANS_SPEED * fps_fac);

	RotateBy(xRot, yRot);
	MoveForward(trans);
}
///////////////////////////////////////////////////////////////////////////////

//WTDrop stuff/////////////////////////////////////////////////////////////
PWTDrop Camera::AddDrop(PWTBitmap &wt_bmp, const BOOL front)
{
	PWTDrop drp = m_wt_camera->addDrop(wt_bmp, front);
	return drp;
}
void Camera::RemoveDrop(PWTDrop &wt_drp)
{
	m_wt_camera->removeDrop(wt_drp);
}
///////////////////////////////////////////////////////////////////////////