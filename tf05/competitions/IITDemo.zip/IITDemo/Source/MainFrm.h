#pragma once

#include "engine/engine.h"

class CMainFrame : public CFrameWindowImpl<CMainFrame, CAxWindow>,
	public IDispEventImpl<0, CMainFrame, &DIID__IWTEvents>	// the wt3d callback interface
{
public:
	typedef	IDispEventImpl<0, CMainFrame, &DIID__IWTEvents>	WTEvents;


	DECLARE_FRAME_WND_CLASS(NULL, IDR_MAINFRAME)

	BEGIN_MSG_MAP(CMainFrame)
		MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
		MESSAGE_HANDLER(WM_CREATE, OnCreate)
	END_MSG_MAP()

	// setup the callback bindings for the wt3d events
	BEGIN_SINK_MAP(CMainFrame)
		SINK_ENTRY_EX(0, DIID__IWTEvents, 5101, OnRender)
		SINK_ENTRY_EX(0, DIID__IWTEvents, 5100, OnMouse)
		SINK_ENTRY_EX(0, DIID__IWTEvents, 5102, OnKeyboard)
		SINK_ENTRY_EX(0, DIID__IWTEvents, 5103, OnException)
	END_SINK_MAP()

	LRESULT OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/);
	LRESULT OnDestroy(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/);

private:
	HRESULT __stdcall OnRender(IWTEvent * eve);
	HRESULT __stdcall OnMouse(IWTEvent * eve);
	HRESULT __stdcall OnKeyboard(IWTEvent * eve);
	HRESULT __stdcall OnException(IWTEvent * eve);

private:
	Engine		m_engine;
	PWT			m_wt;
};