#pragma once

// Typedef these things because it save typing later on,
// and since programmers are lazy people, the less typing the better
typedef CComQIPtr<IWT>					PWT;
typedef CComQIPtr<IWTAudioClip>			PWTAudioClip;
typedef CComQIPtr<IWTBitmap>			PWTBitmap;
typedef CComQIPtr<IWTCamera>			PWTCamera;
typedef CComQIPtr<IWTCollisionInfo>		PWTCollisionInfo;
typedef CComQIPtr<IWTContainer>			PWTContainer;
typedef CComQIPtr<IWTDrop>				PWTDrop;
typedef CComQIPtr<IWTEvent>				PWTEvent;
typedef CComQIPtr<IWTFile>				PWTFile;
typedef CComQIPtr<IWTGroup>				PWTGroup;
typedef CComQIPtr<IWTLight>				PWTLight;
typedef CComQIPtr<IWTModel>				PWTModel;
typedef CComQIPtr<IWTObject>			PWTObject;
typedef CComQIPtr<IWTOrientation3D>		PWTOrientation3d;
typedef CComQIPtr<IWTStage>				PWTStage;
typedef CComQIPtr<IWTSysInfo>			PWTSysInfo;
typedef CComQIPtr<IWTVector3D>			PWTVector3d;
typedef CComQIPtr<IWTKeyboardPollInfo>	PWTKeyboardPollInfo;
typedef CComQIPtr<IWTMousePollInfo>		PWTMousePollInfo;
typedef CComQIPtr<IWTActor>				PWTActor;
