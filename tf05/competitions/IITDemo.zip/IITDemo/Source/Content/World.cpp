#include "stdafx.h"
#include "world.h"

void World::FinalCleanup(void)
{
	m_wt_world.Release();
}
BOOL World::Init(PWT &wt, PWTGroup &group)
{
	BOOL		res = TRUE;

	m_wt_world = wt->createGroupFromFile(_T("world/world.wssc"), 0, 0, 0);
	if (m_wt_world == NULL)
	{
		ERXIT;
	}

	while(!m_wt_world->isLoadedWithChildren()) {}

	group->addObject((PWTContainer)m_wt_world);

xit:
	return res;
}