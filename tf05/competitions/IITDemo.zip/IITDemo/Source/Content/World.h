#pragma once

class World
{
public:
	void			FinalCleanup(void);
	BOOL			Init(PWT &wt, PWTGroup &group);

private:
	PWTGroup		m_wt_world;
};