#include "stdafx.h"
#include "resource.h"

#include "MainFrm.h"

//Event Dispatcher functions
HRESULT CMainFrame::OnRender(IWTEvent * eve)
{
	//m_renderEve = eve;
	m_engine.OnRender(eve);
	return S_OK;
}
HRESULT CMainFrame::OnException(IWTEvent * eve)
{
	//m_exceptionEve = eve;
	m_engine.OnException(eve);
	return S_OK;
}
HRESULT CMainFrame::OnMouse(IWTEvent * eve)
{
	//m_mouseEve = eve;
	m_engine.OnMouse(eve);
	return S_OK;
}
HRESULT CMainFrame::OnKeyboard(IWTEvent * eve)
{
	//m_keyboardEve = eve;
	m_engine.OnKeyboard(eve);
	return S_OK;
}

LRESULT CMainFrame::OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
{
	USES_CONVERSION;
	HRESULT	hr = S_OK;

	CreateControl(L"{FA13A9FA-CA9B-11D2-9780-00104B242EA3}"); // WT3D
	hr = QueryControl(&m_wt);

	// check initialization status
	int checks[] = { 0, 1, 2, 3, 7, 8 };
	char* msgs[] = { "Error - Direct-X version too old. Please update.",
			"Error - Unsupported color depth. Must be played in 16-bit color or better.",
			"Warning - No 3D hardware acceleration found. Your graphics card may not support 3D acceleration, or your Direct-X version may be out of date.",
			"Warning - Your machine does not have a sound card that supports the ADPCM file format. ADPCM sounds will not be used.",
			"Warning - Warning - You are in 24-bit color. If you experience poor performance, switch to 16-bit color.",
			"Warning - You are in 32-bit color. If you experience poor performance, switch to 16-bit color.",
	};
						
	for (int i = 0; i < 6; i++)
	{
		if (m_wt->getInitStatus(checks[i]))
		{
			if (i < 2)
			{
				MessageBox(msgs[i], "Web Driver - Error", MB_OK | MB_ICONERROR);
				CMainFrame::DestroyWindow();
				return 0;
			}
			else 
			{
				MessageBox(msgs[i], "Web Driver - Warning", MB_OK | MB_ICONWARNING);
			}
		}
	}

	hr = AtlGetObjectSourceInterface(m_wt, &(WTEvents::m_libid), &(WTEvents::m_iid), &(WTEvents::m_wMajorVerNum), &(WTEvents::m_wMinorVerNum));
	hr = WTEvents::DispEventAdvise(m_wt, &(WTEvents::m_iid));

	if (!m_engine.Init(this, m_wt))
	{
		return 0;
	}

	return 0;
}
LRESULT CMainFrame::OnDestroy(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& bHandled)
{
	if(m_wt)
	{
		m_engine.FinalCleanup();

		WTEvents::DispEventUnadvise(m_wt, &(WTEvents::m_iid));
		m_wt.Release();
		//m_renderEve.Release();
		//m_keyboardEve.Release();
		//m_mouseEve.Release();
		//m_exceptionEve.Release();
	}

	bHandled = TRUE;
	PostQuitMessage(0);
	return 0;
}