#pragma once

//Common
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tchar.h>
#include <d3dx8math.h>
#include <string>

//ATL
#include <atlbase.h>
#include <atlapp.h>
extern CAppModule _Module;
#include <atlwin.h>
#include <atlframe.h>
#include <atlctrls.h>
#include <atldlgs.h>

//WT
#import "c:\windows\wt\webdriver\webdriver.dll" no_namespace, named_guids
#include "wttypedefs.h"

//SID
#undef		SID_DEBUG
#ifdef _DEBUG
	#define		SID_DEBUG
#endif _DEBUG

#define ERXIT	{ res = FALSE ; goto xit ; }