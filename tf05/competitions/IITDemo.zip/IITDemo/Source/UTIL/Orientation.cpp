#include "stdafx.h"
#include "orientation.h"

namespace UTIL
{

Orientation::Orientation(void) : m_xRot(0.0f), m_yRot(0.0f)
{
	Init();
}
void Orientation::Init(void)
{
	D3DXMatrixIdentity(&m_finalMat);

	m_position.x = m_position.y = m_position.z = m_xRot = m_yRot = 0.0f;
}

void Orientation::GetPosition(D3DXVECTOR3 &pos)
{
	pos.x = m_position.x;	pos.y = m_position.y;	pos.z = m_position.z;
}
void Orientation::GetLookAt(D3DXVECTOR3 &v)
{
	v.x = m_finalMat._13;	v.y = m_finalMat._23;	v.z = m_finalMat._33;
}
void Orientation::GetLookUp(D3DXVECTOR3 &v)
{
	v.x = m_finalMat._12;	v.y = m_finalMat._22;	v.z = m_finalMat._32;
}
void Orientation::GetRotationXY(float &pitch, float &yaw)
{
	pitch = m_xRot;
	yaw = m_yRot;
}

void Orientation::SetPosition(const D3DXVECTOR3 &pos)
{
	m_position.x = pos.x;			m_position.y = pos.y;			m_position.z = pos.z;
	m_finalMat._41 = m_position.x;	m_finalMat._42 = m_position.y;	m_finalMat._43 = m_position.z;
}
void Orientation::SetRotation(const float pitch, const float yaw)
{
	D3DXMATRIX	matX, matY;

	m_xRot = pitch;
	m_yRot = yaw;

	//Keep it between 0 to 360
	while(m_xRot > 360.0f)
		m_xRot -= 360.0f;
	while(m_yRot > 360.0f)
		m_yRot -= 360.0f;

	while(m_xRot < 0.0f)
		m_xRot += 360.0f;
	while(m_yRot < 0.0f)
		m_yRot += 360.0f;

	const float xRot = D3DXToRadian(m_xRot);
	const float yRot = D3DXToRadian(m_yRot);

	D3DXMatrixIdentity(&matX);
	D3DXMatrixIdentity(&matY);

	D3DXMatrixRotationX(&matX, xRot);
	D3DXMatrixRotationY(&matY, yRot);
	D3DXMatrixMultiply(&m_finalMat, &matY, &matX);

	m_finalMat._41 = m_position.x;	m_finalMat._42 = m_position.y;	m_finalMat._43 = m_position.z;
}
//Adds this angle to existing rotation
void Orientation::RotateBy(const float pitch, const float yaw)
{
	if (0.0f == pitch && 0.0f == yaw)
		return;
	SetRotation(m_xRot + pitch, m_yRot + yaw);
}

//Add this translation to the position
void Orientation::MoveForward(const float trans)
{
	if (0.0f == trans)
		return;
	m_finalMat._41 += trans * m_finalMat._13;
	m_finalMat._42 += trans * m_finalMat._23;
	m_finalMat._43 += trans * m_finalMat._33;
	m_position.x = m_finalMat._41;	m_position.y = m_finalMat._42;	m_position.z = m_finalMat._43;
}
void Orientation::MoveForwardIgnoreY(const float trans)
{
	if (0.0f == trans)
		return;
	m_finalMat._41 += trans * m_finalMat._13;
	m_finalMat._43 += trans * m_finalMat._33;
	m_position.x = m_finalMat._41;	m_position.y = m_finalMat._42;	m_position.z = m_finalMat._43;
}
void Orientation::MoveUp(const float trans)
{
	if (trans == 0.0f)
		return;
	m_finalMat._41 += trans * m_finalMat._12;
	m_finalMat._42 += trans * m_finalMat._22;
	m_finalMat._43 += trans * m_finalMat._32;
	m_position.x = m_finalMat._41;	m_position.y = m_finalMat._42;	m_position.z = m_finalMat._43;
}
void Orientation::MoveStrafe(const float trans)
{
	if (trans == 0.0f)
		return;
	m_finalMat._41 += trans * m_finalMat._11;
	m_finalMat._42 += trans * m_finalMat._21;
	m_finalMat._43 += trans * m_finalMat._31;
	m_position.x = m_finalMat._41;	m_position.y = m_finalMat._42;	m_position.z = m_finalMat._43;
}
void Orientation::MoveStrafeIgnoreY(const float trans)
{
	if (trans == 0.0f)
		return;
	m_finalMat._41 += trans * m_finalMat._11;
	m_finalMat._43 += trans * m_finalMat._31;
	m_position.x = m_finalMat._41;	m_position.y = m_finalMat._42;	m_position.z = m_finalMat._43;
}
D3DXVECTOR3& Orientation::GetMoveFowardBy(D3DXVECTOR3 &p, const float trans)
{
	p.x = trans * m_finalMat._13;
	p.y = trans * m_finalMat._23;
	p.z = trans * m_finalMat._33;
	return p;
}
D3DXVECTOR3& Orientation::GetMoveFowardByIgnoreY(D3DXVECTOR3 &p, const float trans)
{
	p.x = trans * m_finalMat._13;
	p.y = 0.0f;
	p.z = trans * m_finalMat._33;
	return p;
}
D3DXVECTOR3& Orientation::GetMoveUpBy(D3DXVECTOR3 &p, const float trans)
{
	p.x = trans * m_finalMat._12;
	p.y = trans * m_finalMat._22;
	p.z = trans * m_finalMat._32;
	return p;
}
D3DXVECTOR3& Orientation::GetMoveStrafeBy(D3DXVECTOR3 &p, const float trans)
{
	p.x = trans * m_finalMat._11;
	p.y = trans * m_finalMat._21;
	p.z = trans * m_finalMat._31;
	return p;
}
D3DXVECTOR3& Orientation::GetMoveStrafeByIgnoreY(D3DXVECTOR3 &p, const float trans)
{
	p.x = trans * m_finalMat._11;
	p.y = 0.0f;
	p.z = trans * m_finalMat._31;
	return p;
}
///////////////////////////////////////////////////////////////////////////

//Set orientation of container/////////////////////////////////////////////////
void Orientation::SetOrientation(PWTContainer c)
{
	c->setAbsoluteOrientationVector(m_finalMat._13, m_finalMat._23, m_finalMat._33,
		m_finalMat._12, m_finalMat._22, m_finalMat._32);
}
void Orientation::SetOrientationIgnoreY(PWTContainer c)
{
	c->setAbsoluteOrientationVector(m_finalMat._13, 0.0f, m_finalMat._33,
			m_finalMat._12, m_finalMat._22, m_finalMat._32);
}
///////////////////////////////////////////////////////////////////////////////

}	//namespace UTIL