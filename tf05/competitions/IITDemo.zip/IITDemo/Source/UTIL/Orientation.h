#pragma once

namespace UTIL
{

class Orientation
{
public:
	Orientation(void);
	void			Init(void);

	void			GetPosition(D3DXVECTOR3 &pos);
	void			GetLookAt(D3DXVECTOR3 &v);
	void			GetLookUp(D3DXVECTOR3 &v);
	void			GetRotationXY(float &pitch, float &yaw);			//in degrees.

	void			SetPosition(const D3DXVECTOR3 &pos);
	void			SetRotation(const float pitch, const float yaw) ;	//in degrees.
	void			RotateBy(const float pitch, const float yaw);

	void			MoveForward(const float trans);
	void			MoveForwardIgnoreY(const float trans);
	void			MoveUp(const float trans);
	void			MoveStrafe(const float trans);
	void			MoveStrafeIgnoreY(const float trans);
	D3DXVECTOR3&	GetMoveFowardBy(D3DXVECTOR3 &p, const float trans);
	D3DXVECTOR3&	GetMoveFowardByIgnoreY(D3DXVECTOR3 &p, const float trans);
	D3DXVECTOR3&	GetMoveUpBy(D3DXVECTOR3 &p, const float trans);
	D3DXVECTOR3&	GetMoveStrafeBy(D3DXVECTOR3 &p, const float trans);
	D3DXVECTOR3&	GetMoveStrafeByIgnoreY(D3DXVECTOR3 &p, const float trans);

	//Set orientation of container
	void			SetOrientation(PWTContainer c);
	void			SetOrientationIgnoreY(PWTContainer c);

private:
	D3DXMATRIX		m_finalMat;
	D3DXVECTOR3		m_position;
	float			m_xRot, m_yRot;		//in degrees
};

}	//namespace UTIL