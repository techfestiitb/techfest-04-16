The WildTangent Web Driver
--------------------------
The Web Driver provides a platform for the development of high quality, high performance, compact 2D  and 3D content for the Internet.  It consists of a high level API for Java, JavaScript, and other COM  enabled languages such as C, C++ and Visual Basic, and has a powerful graphical engine underneath.   The API provides both 2D and 3D support, allowing the creation of everything from simple 2D or 3D  content such as product visualizations for e-commerce, through to full-fledged 3D games.  All of  these can run within a web page, simply by visiting a web site.

The Web Driver consists of a downloadable component of under 1MB, and includes an updater mechanism  to provide an easy way to distribute new versions with additional functionality and maintenance  fixes.  The user only has to install the Web Driver once, and after that the updater will  automatically update the Web Driver when the computer is connected to the Internet (via a background  process that uses idle or unused bandwidth), preventing the need for further delays and downloads at  the time the content is viewed.  The Updater also provides information to WildTangent about error  conditions on the user�s machine, as well as relevant hardware information necessary to reproduce and  fix the issue.  With the Updater, we can be extremely proactive about fixing issues and implementing  new features, so that we can ensure that the user experience remains a positive one.

The plug-in includes Java and JavaScript interface layers, for use by Java/JavaScript enabled  Internet Explorer and Netscape browsers. While the Web Driver was designed for the Internet, it also  has a COM interface that can be used in standalone applications as well, using languages such as  Visual Basic, C, and C++ .

There is extensive documentation available in the Developer Central section of our website on how to  develop and use the Web Driver. This document provides information on the design goals of the Web  Driver, and how those goals are met through the Web Driver�s features.

Read more at: http://www.wildtangent.com/developer/downloads/overviews/WebDriverOverview/index.html

----------------------------------------------------------------------------------------------

IITDemo
-------

A project you'll need to get started using the Web Driver and C++.

Features:
* Load world
* Free camera mode
* WTDrop

Key controls:
-------------
A - move camera forward
Z - move camera back
Up, down, left & right arrow - rotate camera

Requirements to build project:
------------------------------
Visual Studio .Net 2003
WildTangent:	Web Driver 3.0 SDK 
WTL:		http://sourceforge.net/projects/wtl/