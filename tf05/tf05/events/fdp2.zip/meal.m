function [outlet] = mealmodel(inlet)
Ch = inlet(1);
Vmaxge = inlet(2);
timeelapsed = inlet(3);
if Ch < 10800
    Tascge = Ch/Vmaxge;
    Tdesge = Ch/Vmaxge;
else Tascge = 30;
    Tdesge = 30;
end;

Tmaxge = (Ch - (1/2)* Vmaxge* (Tascge + Tdesge)) / Vmaxge;
Ch_critical = ((Tascge + Tdesge) * Vmaxge/2);

if timeelapsed < Tascge 
    Gempt = (Vmaxge/Tascge) * timeelapsed;
else if ( timeelapsed <= (Tascge + Tmaxge))   
        Gempt = Vmaxge;
    else if (timeelapsed < (Tmaxge + Tascge + Tdesge))
            Gempt = (Vmaxge - (Vmaxge/Tdesge) *(timeelapsed - Tascge - Tmaxge));
        else Gempt = 0;
        end;
    end;
end;

outlet(1) = Ch_critical;
outlet(2) = Gempt;

