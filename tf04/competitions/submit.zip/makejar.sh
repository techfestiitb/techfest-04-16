#!/bin/bash

if [ $# -lt 2 ]; then
	echo "Usage: makejar packageName mainRobotFile" 
	echo "Note:"
	echo "1. packageName should be your registration number"
	echo "2. mainRobotFile is your class that extends Robot"
	echo "3. Example:"
	echo "makejar samples BasicRobot"
	exit
fi
jar -cvf "$1.$2.jar" robots/$1

if [ $? -eq 0 ]; 
then
	echo "jar file $1.$2.jar succesfully created"
else
	echo "Could not create jar file!"
fi

