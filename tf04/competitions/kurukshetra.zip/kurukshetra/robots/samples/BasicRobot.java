package samples;
import robowars.*;
import java.math.*;
import java.util.*;

public class BasicRobot extends Robot {
	double turnAngle=Math.PI/2.0;
	double d=100;
	double gunTurnAngle=0.01; 	

	double angDiff(double a1,double a2) {
		// return a2 - a1, assuming both are in range 0 to 2pi
		double diff;
		if (a2>=a1) diff= a2-a1;
		else diff=2.0*Math.PI-a1+a2;

		if (diff>Math.PI) diff=diff-Math.PI*2.0;

		return diff;
	}
	public void execute() {
		char[][] mymap=getMap();
		double w;
		double h;
		double health;
		ahead(d);
		turn(turnAngle);
		turnGun(gunTurnAngle);

		while(true) {
			ArrayList visibleRobots=getVisibleRobots();
			if (visibleRobots.size()>0) { //I see an opponent
				RobotInformation visRobot=(RobotInformation)visibleRobots.get(0);
				double badx=visRobot.getX();
				double bady=visRobot.getY();
				double gunHeading;
				double angletogetto = Math.atan2((bady - getY()),(badx - getX()));
				gunHeading=getGunOrientation(); // angle returned is in the range [0-2PI)
				angletogetto+=Math.PI*2.0; // make it positive
				if (angletogetto>=Math.PI*2.0) { // convert it in the range [0-2PI)
					angletogetto-=Math.PI*2.0;
				}
				double angdiff=angDiff(gunHeading, angletogetto); // compute angle to turn the gun by
				turnGun(angdiff); //turn the gun by angdiff
			}           
			update();
		}
	}	

	public void onHitRobot(HitRobotEvent event){
		d=-d;
		ahead(d);
		turn(Math.PI/2.0);

	}

	public void onHitWall(HitWallEvent event){
		d=-d;
		ahead(d);
		turn(Math.PI/2.0);
	}


	public void onDistanceComplete(DistanceCompleteEvent dce) {
		d=-d;
		ahead(d);
		// function called when linear movement completes
	}

	public void onTurnComplete(TurnCompleteEvent tce) {
		// function called when rotation movement completes
		turnAngle=-turnAngle;
		turn(turnAngle);
	}

	public void onGunTurnComplete(GunTurnCompleteEvent gtce){
		// function called when gun rotation movement completes
		if (getGunHeat()==0) {
			fire(1);
		}
	}         
	public void onWin(WinEvent we) {
		//I win
		ahead(10);
		turn(Math.PI);
	}

	public void onDeath(DeathEvent de) {
		// I die
		ahead(10);
		turn(Math.PI);
	}
}

