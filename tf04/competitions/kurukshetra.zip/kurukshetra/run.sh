#!/bin/sh

mapFile=$1

if [ "$mapFile" = "" ]; then
	mapFile="map.txt"
fi

roboFile=$2
if [ "$roboFile" = "" ]; then
	roboFile="roboList.txt"
fi

screenWidth=$3
if [ "$screenWidth" = "" ]; then
	screenWidth="600"
fi

screenHeight=$4
if [ "$screenHeight" = "" ]; then
	screenHeight="600"
fi

no_of_rounds=$5
if [ "$no_of_rounds" = "" ]; then
	no_of_rounds="3"
fi

#Set the JDK_home envirinment variable to the absolute path of the directory where java is installed
#export JDK_HOME=""

#Set the INSTALL envirinment variable to the absolute path of the directory where you have downlaoded 
#the software
#export INSTALL=""


if [ "$JDK_HOME" = "" ]; then
	echo -e "\n\nJDK_HOME environment variable not set. \nSet it to the absolute path of the directory where java is installed"
	echo -e "Use the following command \nexport JDK_HOME=\"absolute path of the directory where java is installed\"\n"
	exit;
fi

if [ "$INSTALL" = "" ]; then
	echo -e "\n\nINSTALL environment variable not set. \nSet it to the absolute path of the directory where the software is downloaded"
	echo -e "Use the following command \nexport INSTALL=\"absolute path of the directory where the software is installed\"\n"
	exit;
fi

INSTALL="$INSTALL"/kurukshetra
export SAMPLE_ROBOTS="$INSTALL"/robots
export PATH=$PATH:.:$JDK_HOME/bin
export CLASSPATH=.:"$INSTALL"/robowars.jar:"$JDK_HOME"/lib/dt.jar:"$SAMPLE_ROBOTS"
echo $CLASSPATH
java -Xmx256M -cp "$INSTALL"/robowars.jar:$SAMPLE_ROBOTS robowars.Server $mapFile $roboFile $screenWidth $screenHeight $no_of_rounds
