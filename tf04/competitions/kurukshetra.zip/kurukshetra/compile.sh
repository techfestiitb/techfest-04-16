
#Set the JDK_home envirinment variable to the absolute path of the directory where java is installed
#export JDK_HOME=""

#Set the INSTALL envirinment variable to the absolute path of the directory where you have downlaoded the software
#export INSTALL=""


if [ "$JDK_HOME" = "" ]; then
	echo -e "\n\nJDK_HOME environment variable not set. \nSet it to the absolute path of the directory where java is installed"
	echo -e "Use the following command \nexport JDK_HOME=\"absolute path of the directory where java is installed\"\n"
	exit;
fi

if [ "$INSTALL" = "" ]; then
	echo -e "\n\nINSTALL environment variable not set. \nSet it to the absolute path of the directory where the software is downloaded"
	echo -e "Use the following command \nexport INSTALL=\"absolute path of the directory where the software is installed\"\n"
	exit;
fi

packageName=$1
if [ "$packageName" = "" ]; then
	echo -e "Usage: compile.sh packageName\n"
	exit;
fi
INSTALL="$INSTALL"/kurukshetra
export SAMPLE_ROBOTS="$INSTALL"/robots
export PATH=$PATH:.:$JDK_HOME/bin
export CLASSPATH="$INSTALL"/robowars.jar:"$JDK_HOME"/lib/rt.jar
echo $CLASSPATH

javac $SAMPLE_ROBOTS/$packageName/*.java 
